const WebDesign = () => {
  return <h2>Web design content</h2>;
};

export default WebDesign;
