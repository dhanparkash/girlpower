const PHP = () => {
  return <h2>PHP</h2>;
};

export default PHP;
