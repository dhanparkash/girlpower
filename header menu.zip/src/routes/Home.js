import React from 'react'; 
import rightimage from '../images/rectangletwo.png';
import leftimage from '../images/sheroescafe.jpg';
import mutedVideo from '../images/gpt-banner-hero-bg-compressed-1.mp4';
const Home = () => {
  return  (
  <div class="main-content">
<div class="col-md-12" id="topvideos">
<video autoPlay muted loop>
        <source src={mutedVideo} />
      </video>
</div>
<div class="container">
<div class="row">
<div class="col-md-6 play-card">
About Us
We believe that achieving true gender equality requires a radical shift in the way young women are mentored in the workplace.
At Girl Power Talk, we are passionately dedicated to empowering women–as well as men and nonbinary individuals–with opportunities to learn confidently, feel valued, and build a career full of purpose.

“Let’s unlock your potential. Welcome to Girl Power Talk.“
</div>
<div class="col-md-6">
<img src={rightimage} className="App-logos" alt="logo" />
</div>
<div class="col-md-6">
<img src={leftimage} className="App-logos" alt="logo" />
</div>
<div class="col-md-6 play-card">
About Us
We believe that achieving true gender equality requires a radical shift in the way young women are mentored in the workplace.
At Girl Power Talk, we are passionately dedicated to empowering women–as well as men and nonbinary individuals–with opportunities to learn confidently, feel valued, and build a career full of purpose.

“Let’s unlock your potential. Welcome to Girl Power Talk.“
</div>
</div>
</div>
  </div>
    );
};

export default Home;
