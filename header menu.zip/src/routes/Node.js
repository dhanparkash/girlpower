const Node = () => {
  return <h2>Node</h2>;
};

export default Node;
