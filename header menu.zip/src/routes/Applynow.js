import React from 'react';

const Applynow = () => {
  return <h2>Apply Now </h2>;
};

export default Applynow;
