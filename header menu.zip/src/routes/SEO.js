const SEO = () => {
  return <h2>Search engine optimization</h2>;
};

export default SEO;
