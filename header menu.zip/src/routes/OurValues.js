const OurValues = () => {
  return <h2>Our values</h2>;
};

export default OurValues;
