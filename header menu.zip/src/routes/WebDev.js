import React from 'react';

const WebDev = () => {
  return <h2>Web development content</h2>;
};

export default WebDev;
