import { Link } from 'react-router-dom';
import footerback from '../images/FooterBackground.png';
import footerLogo from  '../images/gptusafooter.png';
const Footer = () => {
  return (
    <div class="footer" style={{ backgroundImage: `url(${footerback})` }}> 
    <div class="container">  
    <div class="row">
       <div class="col-md-4">
      <Link to="/" className="logo">
      <img src={footerLogo} className="App-logos" alt="logo" />
      </Link>
      </div>
      </div>
    </div> 
    </div>   
  );
};

export default Footer;
